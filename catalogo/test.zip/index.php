<?php 
	include("topo.php");

 
	include("rodape.php");

 
?>
