    <!-- Footer -->
    
	<footer class="py-5 bg-dark">
      
<div class="container">
        
<p class="m-0 text-center text-white">Copyright &copy; 2018 Terra Produtiva</p>
      
</div>
      
<!-- /.container -->
   
 </footer>

    
<!-- Bootstrap core JavaScript -->
    
<script src="vendor/jquery/jquery.min.js"></script>
    
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Contact form JavaScript -->
    <!-- Do not edit these files! In order to set the email address and subject line for the contact form go to the bin/contact_me.php file. -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
  </body>

</html>